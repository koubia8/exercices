<?php

namespace App\Http\Controllers;
use App\Scholarship;
use \GuzzleHttp\Client;
use GuzzleHttp\Psr7;
use GuzzleHttp\Exception\RequestException;
use Illuminate\Http\Request;

class ScholarshipController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function createInfoScholarship(Request $request){
            $client = new \GuzzleHttp\Client();
            try {
                $res = $client->request('GET', 'localhost:9001/api/student/'.$request->numeroEtudiant);
                $student = json_decode($res->getBody(),true);
                $student["numeroEtudiant"];
                $scholarship  = new Scholarship();
                $scholarship->numeroEtudiant=$student["numeroEtudiant"];
                $scholarship->status = $request->status;
                $scholarship->montantScholarship = $request->montantScholarship;
                $scholarship->save(); 
                return response()->json('scholarship ajoutée  avec succés !');
            } catch (RequestException $e) {
                return response()->json(Psr7\Message::toString($e->getRequest()));
                if ($e->hasResponse()) {
                    return response()->json(Psr7\Message::toString($e->getResponse()));
                }
            }
    
        
    }
    

    //
}
