package sn.ucad.informatique.soa.msstage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Service
public class InternshipService {
    @Autowired
    private InternshipRepository stageRepository;
    private final String apiEtudiant = "http://localhost:9001/api/etudiant";

    public Internship createStage(InternshipRequest stageRequest){
        RestTemplate restTemplate = new RestTemplate();
        restTempletInstance(stageRequest.getNumeroEtudiant());
        Internship newStage= new Internship();
        newStage.setNumeroEtudiant(stageRequest.getNumeroEtudiant());
        newStage.setNomEntreprise(stageRequest.getNomEntreprise());
        return stageRepository.save(newStage);
    }

    private void  restTempletInstance(String numeroEtudiant){
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<Object> response= restTemplate.getForEntity(apiEtudiant+"/"+numeroEtudiant, Object.class);
        if(response.getStatusCode().equals(HttpStatus.NOT_FOUND)){
            throw new StudentNotFoundException(String.format("Le numero %s n'existe pas dans la base donnée etudiant",numeroEtudiant));
        }
    }
    private Student  getEtudiant(String numeroEtudiant){
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<Student> response= restTemplate.getForEntity(apiEtudiant+"/"+numeroEtudiant, Student.class);
        if(response.getStatusCode().equals(HttpStatus.NOT_FOUND)){
            throw new StudentNotFoundException(String.format("Le numero %s n'existe pas dans la base donnée etudiant",numeroEtudiant));
        }
        return  response.getBody();
    }

    public InternshipReponse findStageForEtudiant(String numero){
        List<Internship> stages= new ArrayList<>();
        List<Internship> stageFromDb= stageRepository.findStageByNumeroEtudiant(numero);
        // information etudiant : api etudiant
        Student etudiant = getEtudiant(numero);
        // mes stages effectués
        stageFromDb.forEach(stage -> {
            Internship stageReponse = new Internship();
            stageReponse.setNomEntreprise(stage.getNomEntreprise());
            stages.add(stageReponse);
        });
        // object de reponse liste des stages

        InternshipReponse internshipReponse = new InternshipReponse();
        internshipReponse.setEtudiant(etudiant);
        internshipReponse.setMesStage(stages);
        return internshipReponse;
    }
}
