package sn.ucad.informatique.soa.msstage;

import lombok.Data;

@Data
public class Student {
    private String numeroEtudiant;
    private String nom;
    private String prenom;
}
