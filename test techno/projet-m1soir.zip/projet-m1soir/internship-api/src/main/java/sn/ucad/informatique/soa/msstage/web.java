package sn.ucad.informatique.soa.msstage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/intershipService")
public class web {
    @Autowired
    private InternshipService internshipService;

    @PostMapping
    public ResponseEntity<Internship> createNewStage(@Valid @RequestBody InternshipRequest stageRequest){
        return ResponseEntity.ok(internshipService.createStage(stageRequest));
    }

    @GetMapping("/{numero}")
    public ResponseEntity<InternshipReponse> findStageForEtudiant(@PathVariable("numero") String numero){
        return ResponseEntity.ok(internshipService.findStageForEtudiant(numero));
    }
}
