package sn.ucad.informatique.soa.msstage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsInternshipApplicationTests {

	@Test
	void contextLoads() {
	}

}
