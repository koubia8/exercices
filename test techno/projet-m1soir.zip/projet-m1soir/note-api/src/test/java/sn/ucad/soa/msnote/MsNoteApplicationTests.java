package sn.ucad.soa.msnote;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsNoteApplicationTests {

	@Test
	void contextLoads() {
	}

}
