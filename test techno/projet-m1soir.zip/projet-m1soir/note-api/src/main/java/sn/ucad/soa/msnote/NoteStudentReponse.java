package sn.ucad.soa.msnote;

import lombok.Data;

import java.util.List;

@Data
public class NoteStudentReponse {
    private Student etudiant;
    private List<Note> mesNotes;
}
