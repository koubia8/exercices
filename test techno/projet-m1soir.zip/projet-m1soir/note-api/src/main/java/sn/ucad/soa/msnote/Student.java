package sn.ucad.soa.msnote;

import lombok.Data;

import java.io.Serializable;

@Data
public class Student implements Serializable {
    private String nom;
    private String prenom;
    private String numeroEtudiant;
}
