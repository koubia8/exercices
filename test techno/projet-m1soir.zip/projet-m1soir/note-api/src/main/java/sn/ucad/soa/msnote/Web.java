package sn.ucad.soa.msnote;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/note")
public class Web {
    @Autowired
    private NoteService noteService;

    @PostMapping
    public ResponseEntity<Note> createNote(@Valid  @RequestBody NoteRequest noteRequest){
        return ResponseEntity.ok(noteService.createNewNote(noteRequest));
    }

    @GetMapping("/{numero}")
    public ResponseEntity<NoteStudentReponse> findNoteByNumeroEtudiant(@PathVariable("numero") String numero){
        return ResponseEntity.ok(noteService.findNoteByEtudiant(numero));
    }

}
