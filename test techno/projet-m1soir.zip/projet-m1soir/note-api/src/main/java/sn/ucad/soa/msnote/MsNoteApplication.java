package sn.ucad.soa.msnote;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsNoteApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsNoteApplication.class, args);
	}

}
