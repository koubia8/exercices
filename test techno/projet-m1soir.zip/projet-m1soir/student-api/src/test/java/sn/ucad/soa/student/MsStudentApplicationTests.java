package sn.ucad.soa.student;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsStudentApplicationTests {

	@Test
	void contextLoads() {
	}

}
