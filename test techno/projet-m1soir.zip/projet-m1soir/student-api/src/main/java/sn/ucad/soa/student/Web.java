package sn.ucad.soa.student;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/stutend")
public class Web {
    @Autowired
    private StudentService studentService;

    @PostMapping
    private ResponseEntity<Student> createNewEtudiant(@Valid @RequestBody StudentRequest etudiantRequest){
        return ResponseEntity.ok(studentService.createNewEtudiant(etudiantRequest));
    }
    @GetMapping("/{numero}")
    private ResponseEntity<Student> getEtudiant(@PathVariable("numero") String numero){
        return ResponseEntity.ok(studentService.getEtudiantByNumeroClient(numero));
    }

    @GetMapping
    private ResponseEntity<List<Student>> findAll(){
        return ResponseEntity.ok(studentService.findAllEtudiant());
    }
}
