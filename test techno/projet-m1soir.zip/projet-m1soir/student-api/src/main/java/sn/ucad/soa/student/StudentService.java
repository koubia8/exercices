package sn.ucad.soa.student;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StudentService {
    @Autowired
    private StudentRepository studentRepository;

    public Student createNewEtudiant(StudentRequest etudiantRequest){
        Optional<Student> etudiantFromDB= studentRepository.findEtudiantByNumeroEtudiant(etudiantRequest.getNumeroEtudiant());
        if (etudiantFromDB.isPresent()){
            throw new StudentConflitException(String.format("Le numéro %s de l'etudiant existe dèja ",etudiantRequest.getNumeroEtudiant()));
        }
        Student newStudent = new Student();
        newStudent.setNom(etudiantRequest.getNom());
        newStudent.setPrenom(etudiantRequest.getPrenom());
        newStudent.setNumeroEtudiant(etudiantRequest.getNumeroEtudiant());
        return studentRepository.save(newStudent);
    }
    public Student getEtudiantByNumeroClient(String numero){
        Optional<Student> etudiantFromDB = studentRepository.findEtudiantByNumeroEtudiant(numero);
        if (etudiantFromDB.isEmpty()){
            throw new StudiantNotFoundException(String.format("Le numéro %s de l'etudiant existe pas",numero));
        }
        return  etudiantFromDB.get();
    }

    public List<Student> findAllEtudiant(){
        return studentRepository.findAll();
    }
}
